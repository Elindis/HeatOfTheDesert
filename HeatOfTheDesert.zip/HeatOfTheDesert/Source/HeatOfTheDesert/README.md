# Heat of the Desert
A RimWorld mod that makes hot regions harder to survive in

In this version, players can configure some new heat-related behaviours for all vanilla plants, including the ability to lower the ideal growth temperature, maximum growth temperature, and - most imporantly - whether plants can die in high temperatures, and at which temperature that starts to happen.
