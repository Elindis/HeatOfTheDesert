# HeatOfTheDesert
A RimWorld mod that makes hot regions harder to survive in

In this version, a basic implementation allows for all vanilla plants to grow slowly in intense heat, and die at a certain temperature.
